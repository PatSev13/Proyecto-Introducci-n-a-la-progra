package proyecto;

import javax.swing.JOptionPane;

public class Informacion {
    
    private byte opcion = 0;
    
    public void Info(){ 
    
    do {
    
     opcion = Byte.parseByte(JOptionPane.showInputDialog(null,    "\n****       MENÚ DE INFORMACIÓN        ****\n "+
      "     1 = DATOS ZONA TEMÁTICA 1  \n"
    + "      2 = DATOS ZONA TEMÁTICA 2  \n"
    + "      3 = DATOS ZONA TEMÁTICA 3  \n"
    + "      4 = DATOS ZONA TEMÁTICA 4  \n"
    + "      5 = DATOS ZONA TEMÁTICA 5  \n"
    +  "      6 = SALIR                                        \n\n"
    +"Digite un número: " + "\n"));  
     if (opcion == 1){
         
            JOptionPane.showMessageDialog(null, "Descubre Star Wars: Galaxy's Edge – una tierra nueva en donde puedes vivir tu propia historia de Star Wars, \nvolar en el Halcón Milenario y explorar "
                    + "un remoto asentamiento en donde te esperan grandes aventuras.");
            
            JOptionPane.showMessageDialog(null, "\nEsta zona cuenta con dos atracciones principales: "
                    + "el Millennium Falcon: Smugglers Run y Star Wars: Rise of the Resistance.");
            JOptionPane.showMessageDialog(null, "\nLa primera de ellas, consiste en un simulador del famoso Halcón Milenario, y "
                    + "donde se puede pilotar la célebre nave de Han Solo "
                    + "construida a escala real para una experiencia que \nresponde en tiempo real a las decisiones y acciones que se toman;\ny la segunda "
                    + "atracción sitúa a los visitantes en medio de una batalla climática entre \nla Primera Orden y la Resistencia en una aventura interactiva.");
                    }
     if (opcion == 2){ 
          
           JOptionPane.showMessageDialog(null, "Descubre Harry Potter:The wizarding word of Harry Potter - entra al lugar donde te volveras un verdadero mago y disfrutaras de un dia magico en familia.");
           
           JOptionPane.showMessageDialog(null, "Esta zona cuenta con dos  imprecionantes atracciones principales.");
           
           JOptionPane.showMessageDialog(null,"\nLa primera de ellas, consisteen entrar en una reproduciion del castillo de Hogwarts,"
                   + " y \n donde recorreras los pasillos donde veras los famosos retratos parlantes, "
                   + "\nllegar a la oficiona del director Albus Dumbledore"
                    + "pasar por el salon de Defensa contra artes oscuras y la sla comun de Gryffindor "
                   + "\naqui se encuentra un simulador 4D con Harry Potter y el viaje prohibido"
                   + " \nen el que uno tiene la sensacion de volar de volar en una escoba sobre el castillo;"
                   + "\ny la segunda "
                    + "atracción es una increible montaña rusa llamada El vuelo del Hipogrifo");
     }
           
     if (opcion == 3){   
            
           JOptionPane.showMessageDialog(null, "Descubre Mario Bros: Super Nintendo word entra a  los escenarios y decorado de los videojugos a escala real");
           
           JOptionPane.showMessageDialog(null, "Esta zona cuenta con escenarios de videojuegos a escala real y realidad virtual ademas una atraccion");
           
           JOptionPane.showMessageDialog(null, "La atraccion estrella esta protagonizada por los diferentes automoviles que aparecen es Super Mario karts"
                     + " en donde correras en diferentes mapas contra otras personas y así pareciendo que estas dentro del juego ");
     }       
     if (opcion == 4){
         
         JOptionPane. showMessageDialog(null, "Descubre Magic Shop, "
                 +"\n el primer parque tematico de la banda surcoreana BTS,"
                 +"\nun lugar en donde podras vivir la experiencia"
                      +"\n de estar en todos los MV de los chicos, los escenarios de los conciertos, entre muchas cosas más");
         
         JOptionPane. showMessageDialog(null, "Esta zona del parque cuanta con salas de baile, atracciones de agua, ademas de salas de realidad virtual");
         JOptionPane. showMessageDialog(null, "La atrracion más destacada es la sala de realidad virtual, en donde al rededor"
                      + "de cierto espacio podras elegir tu MV favorito y vivir la experiencia de completar una historia junto a los integrantes");
         
         JOptionPane. showMessageDialog(null, "Podras subir a las enormes atracciones de agua con las tematicas mas divertidas de la banda,"
                 +"\n algunas de estas son catalogadas para personas de cierta edad"
                      +"debido al movimiento y fuerza de sus montañas y para finalizar"
                 +"\n otra de sus más demandadas atracciones es el espacio de Karaoke "
                 +"\n y danza en donde ARMY´s de todo el mundo se reunen para disfrutar de las canciones de la banda");             
     
     }
     
     
          if (opcion == 5){  
         JOptionPane. showMessageDialog(null, "Bienvenidos a Halloweentown,el lugar más escalofriante y divertido que podras visitar,"
                 +"\nEn Halloweentown se podras encontrar Con todos aquellos espectros que aun te siguen causando pesadillas");
     
        JOptionPane. showMessageDialog(null,"En Halloweentown podras estar en completa tematica de la festividad,"
                +"\n visitar sus espeluznantes pero unicos restaurantes y tiendas"
                      +" eso sin mencionar sus aterradoras pero divertidas atrraciones," 
                +"\nsu más famosa atraccion,"
                +"\nel cementerio de los santos, donde con tu equipo tendran que sobrevivir en el cementerio más aterrado,"
                +"\n para llegar a las catacunbas del mismo"
                      + "solamente con la ayuda de una pistola de paintball y un pequeño y roto mapa");
        
        JOptionPane. showMessageDialog(null, "Pobras visitar las hermosas tiendas de ropa en donde estaras a la moda de todos los espectros,"
                +"\ny comer en El castillo de Bran el mejor restaurante de Halloweentown "
                     +"\nuna replica exacta de la antigua vivienda de Vlad Țepeș el Empalador o más conocido como el Conde Dracula"
                     +"Tambien podras entrar en hell hall la mejor y más escalofiante montaña rusa,"
                +"\n en donde podras recibir más de un susto, siendo esta tambien una atraccion con agua");
          }
   } while(opcion != 6);
    
  }
}

