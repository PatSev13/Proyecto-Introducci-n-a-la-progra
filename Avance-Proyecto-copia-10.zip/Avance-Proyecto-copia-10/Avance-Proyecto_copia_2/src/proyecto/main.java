package proyecto;

import javax.swing.JOptionPane;

public class main {

    public static void main(String[] args) {

       Informacion i=new Informacion();
        
       Horarios h=new Horarios();
        
       Menu m= new Menu();
       
       Revision r=new Revision();
       
       Recuerdos re=new Recuerdos();
       
       TerminosS cv=new TerminosS();
       do{
         m.Menu();
       
        if (m.getOpcion() == 1){
         i.Info();

        } else if (m.getOpcion() == 2){
            r.llenarArreglo();
         } else if (m.getOpcion() == 3){
            r.mostrarArreglo();
         } else if (m.getOpcion() == 4){
            JOptionPane.showMessageDialog(null, "Por favor ingrese los datos de nuevo.");
            r.llenarArreglo();
         } else if (m.getOpcion() == 5){
            re.Recuerdos();
         }else if (m.getOpcion() == 6){
            cv.TerminosS();  
         }
          
        
  } while (m.getOpcion() != 7);
       
    JOptionPane.showMessageDialog(null, "Gracias por su visita. ¡Te esperamos!");
}
}
