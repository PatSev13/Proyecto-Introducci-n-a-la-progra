package proyecto;

import javax.swing.JOptionPane;

public class Menu {
    private byte opcion = 0;

    public byte Menu(){
        JOptionPane.showMessageDialog(null, "Para realizar la compra de entradas, por favor ingrese a la opción de ingresar datos\n");

        opcion = Byte.parseByte(JOptionPane.showInputDialog(null,  "\n****       MENÚ PRINCIPAL        ****\n"
       + "         1 = INFORMACIÓN            \n" 
       + "         2 = INGRESAR DATOS         \n"
       + "         3 = REVISAR DATOS          \n"
       + "         4 = CORREGIR DATOS          \n"
       + "         5 = RECUERDOS               \n"           
       + "         6 = TERMINOS DE SALUD       \n"
       + "         7 = SALIR                 \n\n"
       + "Digite un número: "));
        
        return opcion;
    }
    
    
    
    public byte getOpcion() {
        return opcion;
    }

    public void setOpcion(byte opcion) {
        this.opcion = opcion;
    }
    
    
}
