
package proyecto;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class TerminosS {

    public void TerminosS (){
        Scanner cv = new Scanner(System.in);
        
        String nombre;
        byte edad;
        String cedula;
     
        nombre = JOptionPane.showInputDialog(null,"Digite su nombre:");
        cedula = JOptionPane.showInputDialog(null,"Digite su cedula:");
        edad = (byte) Integer.parseInt(JOptionPane.showInputDialog("Digite su edad:"));
     
        
        JOptionPane.showMessageDialog(null," Normativa de salud de los parques"
                 +"\n Cumplir con los 1.8 metros de distanciamineto entre cada persona");
        
        JOptionPane.showMessageDialog(null," Lavado de manos antes de ingresar al parque"
                 +"\n y antes de ingresar a cualquier atraccion o establecimiento");
        
        JOptionPane.showMessageDialog(null," Uso obligatorio de tapabocas a todo momento"
                 +"\n Mantener la burbuja social dentro del parque");
        
        int confir, dato;
        dato = 0;
        
        confir = Integer.parseInt (JOptionPane.showInputDialog(null,"Acepta cumplir con todos los lineamientos de salud implementados por el parque"
              + "coloque un 0 para si y un 1 para no"));
     
        
       if (confir == dato ) {
           
            JOptionPane.showMessageDialog(null,"Yo " +nombre+ " cedula " +cedula+ " y mis acompañantes nos comprometemos a cumplir"
                 +"\n con todas las normas establecidas por los parques");
            JOptionPane.showMessageDialog(null,"debido a la pandemia del Covid-19, ademas de dar fe de nuestra salud"
                 +"\n y de los cuidados previos a ingresar a las instalaciones");
       
    } else{
        JOptionPane.showMessageDialog(null,"Debido a la situacion de pandemia, es necesario aceptar los lineamientos de"
                +"los parques, vuelva al menu principal");
           
           
}
        
}
}    

