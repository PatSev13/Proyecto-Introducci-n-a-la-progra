package proyecto;

import javax.swing.JOptionPane;

import java.util.Scanner;

public class Recuerdos {
public void Recuerdos(){
    Scanner entrada = new Scanner(System.in);
int nelementos;


JOptionPane.showMessageDialog(null, "\nlos objetos que puede comprar son los siguientes"); 
JOptionPane.showMessageDialog(null, "\nSable luz de Star Wars=S \nCapa de invisibilidad de harry Potter=C,"
        +"\n Tarjetas holograficas de BTS=T"
        +"\n Albumés de la banda BTS=A"
        +"\n Disfraz de monstruos=D"
        +"\n Varita magica de Harry Potter=V ");
       
nelementos = Integer.parseInt(JOptionPane.showInputDialog("digite la cantidad de objetos que desea comprar:"));        
        
char [] letras= new char [nelementos];
System.out.println("Digite la inicial de los elementos que desea comprar:");
for(int i=0;i<nelementos;i++){
    
System.out.print((i+1)+ ". Digite la inicial de los objetos:");
    letras[i]=entrada.next().charAt(0);
}
System.out.println("\n Los objetos a comprar son:");
    for(int i=0;i<nelementos;i++){
        System.out.print(letras[i]+" ");
}    
    
}   
}  

