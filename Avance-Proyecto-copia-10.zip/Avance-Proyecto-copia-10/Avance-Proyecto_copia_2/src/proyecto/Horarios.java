package proyecto;

import javax.swing.JOptionPane;

public class Horarios {
    
    private String dia;
    private String hora;
 
    public String Dia(){
        
        dia = JOptionPane.showInputDialog(null, "Te ofrecemos horarios de lunes a viernes de 8:00am a 11:00am y de 1:00pm a 4:00pm en todas las zonas temáticas."
        + "\n\n¿Qué día te gustaría visitarnos? (ingrese solamente el día, ej. Lunes): ");
        
            while ((!"Lunes".equals(dia) && !"lunes".equals(dia) && !"LUNES".equals(dia)) 
    && (!"Martes".equals(dia) && !"martes".equals(dia) && !"MARTES".equals(dia)) 
    && (!"Miércoles".equals(dia) && !"miércoles".equals(dia) && !"MIÉRCOLES".equals(dia) && !"Miercoles".equals(dia) && !"miercoles".equals(dia)&& !"miercoles".equals(dia)) 
    && (!"Jueves".equals(dia) && !"jueves".equals(dia) && !"JUEVES".equals(dia)) 
    && (!"Viernes".equals(dia) && !"viernes".equals(dia) && !"VIERNES".equals(dia))){
                
        JOptionPane.showMessageDialog(null, "Erorr. Ingrese un día válido.");
        dia = JOptionPane.showInputDialog(null,"¿Qué día te gustaría visitarnos? (ingrese solamente el día, ej. Lunes): ");
        
        
         }
            return dia;
    }
     
    public String Hora(){
      //--------------------------------------------------------------------------------------------------------------  
                    
    hora = JOptionPane.showInputDialog(null, "\n¿A qué hora nos visitarías?\nPor favor ingrese solamente la hora de llegada (8:00am o 1:00pm): ");
    
    while ((!"8:00am".equals(hora) && !"8:00AM".equals(hora) && !"8am".equals(hora)  && !"8AM".equals(hora) && !"8".equals(hora)) && 
    (   !"1:00pm".equals(hora) && !"1:00PM".equals(hora) && !"1pm".equals(hora)  && !"1PM".equals(hora) && !"1".equals(hora))){
        JOptionPane.showMessageDialog(null, "Error. Ingrese una hora válida.");
        hora = JOptionPane.showInputDialog(null, "\n¿A qué hora nos visitarías?\nPor favor ingrese solamente la hora de llegada (8:00am o 1:00pm): ");

        
                }
    
      if ("8:00am".equals(hora) || "8:00AM".equals(hora) || "8am".equals(hora)  || "8AM".equals(hora) || "8".equals(hora)){
     JOptionPane.showMessageDialog(null, "\nMuy bien. Te esperamos el " + dia + " a las 8:00am");
             
             
             } else if ("1:00pm".equals(hora) || "1:00PM".equals(hora) || "1pm".equals(hora)  || "1PM".equals(hora) || "1".equals(hora)) {
     JOptionPane.showMessageDialog(null,"\nMuy bien. Te esperamos el " + dia + " a la 1:00pm.\n");

             }
    
    return hora;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }    
}
