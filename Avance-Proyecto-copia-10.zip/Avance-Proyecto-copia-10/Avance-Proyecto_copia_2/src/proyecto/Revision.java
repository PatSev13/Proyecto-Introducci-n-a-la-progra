package proyecto;

import javax.swing.JOptionPane;

public class Revision {
    private Datos datosCliente[] = new Datos[1] ;
    private String s = "";
    
    public void llenarArreglo(){
        int x;
        for (x=0; x < datosCliente.length; x++){
            
            Datos dat= new Datos();
            Horarios h=new Horarios();
            h.Dia();
            h.Hora();
            dat.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre de la persona que compra las entradas: "));
            dat.setCedula(JOptionPane.showInputDialog(null, "Digite el número de cédula de la persona que compra las entradas: "));
            dat.setCantEntradas(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cantidad de entradas adquiridas: ")));
            
            dat.setDia(h.getDia());
            dat.setHora(h.getHora());
            
            datosCliente [x] = dat;
        }
        
    }  
    
   public void mostrarArreglo(){
      int x;
      s = "";
      for(x=0;x<datosCliente.length;x++){
          s=s+"Nombre: "+datosCliente[x].getNombre()+"\n"+
                  "Cédula: "+ datosCliente[x].getCedula()+"\n"+
                  "Entradas adquiridas: " + datosCliente[x].getCantEntradas()+ "\n"+
                  "Día: " + datosCliente[x].getDia() + "\n" +
                  "Hora: "+ datosCliente[x].getHora() +"\n\n" ;
      }
      
      JOptionPane.showMessageDialog(null,
              "Los datos ingresados son:\n"+s);
   }    
   
   /*public void buscarCliente(){
      int x;
      String nombre="";
      nombre=JOptionPane.showInputDialog(null,
              "Digite el nombre del juego que desea buscar: ");
      
      for(x=0;x<datosCliente.length;x++){
            if(nombre.equals(datosCliente[x].getNombre())){
               JOptionPane.showMessageDialog(null,
                 "El cliente que usted busca es "+
                  datosCliente[x].getNombre()+
                  " y sus datos son: \n" +
                  "Cédula: "+ datosCliente[x].getCedula()+"\n"+
                  "Entradas adquiridas: " + datosCliente[x].getCantEntradas()+ "\n"+
                  "Día: " + datosCliente[x].getDia() + "\n" +
                  "Hora: "+ datosCliente[x].getHora() +"\n\n");
      }
        }
      }*/
   }   
